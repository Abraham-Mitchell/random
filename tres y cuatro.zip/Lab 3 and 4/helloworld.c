#include <stdio.h>
#include "platform.h"

#define AXI_GPIO_0_BASE_ADDR 0x40000000
#define AXI_GPIO_1_BASE_ADDR 0x40010000
#define TIMER_BASE_ADDR 0x41c00000
#define TIMER_LOAD_REG_ADDR 0x41c00004

#define TCSR0_REG (unsigned *)(TIMER_BASE_ADDR)
#define TLR0_REG (unsigned *)(TIMER_LOAD_REG_ADDR)


#define GREEN_LEDS_BASE_ADDR (AXI_GPIO_0_BASE_ADDR)
#define PUSH_BTNS_BASE_ADDR  (AXI_GPIO_0_BASE_ADDR + 8)

#define RGB_LEDS_BASE_ADDR (AXI_GPIO_1_BASE_ADDR)
#define RGB_LEDS_REG (unsigned *)(RGB_LEDS_BASE_ADDR)

#define GREEN_LEDS_REG (unsigned *)(GREEN_LEDS_BASE_ADDR)
#define PUSH_BTNS_REG (unsigned *)(PUSH_BTNS_BASE_ADDR)

#define LED_RED 04444
#define LED_GREEN 02222

// Data and tristate register ptrs for the 4 push buttons on the Arty board
unsigned *buttonsData = PUSH_BTNS_REG;
unsigned *buttonsTri  = PUSH_BTNS_REG + 1;

// Data and tristate register ptrs for the 4 rgb LEDs on the Arty board
unsigned *rgbLEDsData = RGB_LEDS_REG;
unsigned *rgbLEDsTri  = RGB_LEDS_REG + 1;

// Set timer parameters
unsigned *TCSR0 = TCSR0_REG;
unsigned *TLR0 = TLR0_REG;

//count variable
unsigned count = 0;

typedef enum
{RED, GREEN, FLASH_RED_START, FLASH_RED_END} State;

// Create state variables
State state, next_state;

// Basic delay function
void delay_ms(int seconds)
{
	// timer parameters
	*TCSR0 = 0x0000;
	*TLR0 = 0x26BDD8C; //81.247 million / 2 for .5 second intervals
	*TCSR0 = 0b000100110010; //load

	*TCSR0 = 0b00010010010;

	int count = 0;
	while(count < seconds){

		if(*TCSR0 & 0b00100000000){
			*TCSR0 |= 0b00100000000;
			count++;
		}
	}

}

unsigned char button_check(){
	if(*buttonsData != 0)
		return 1;
	else
		return 0;
}

void flash_red(){
	*rgbLEDsData = 0;
	delay_ms(1);
	*rgbLEDsData = LED_RED;
	delay_ms(1);
}



// Basic template for FSM model
void FSM_tick()
{
  switch(state)
  {
    case RED:
      // code for RED state & logic for next_state
      *rgbLEDsData = LED_RED;
      delay_ms(9);
      next_state = FLASH_RED_END; // next state after RED
      break;

    case GREEN:
      // code for GREEN state & logic for next_state
      *rgbLEDsData = LED_GREEN;
      if (button_check())
      	next_state = FLASH_RED_START;
      else
    	  next_state = GREEN; // next state after GREEN
      break;

    case FLASH_RED_START:
      // code for FLASH_RED_START state & logic for next_state
      for(int i = 0; i < 6; ++i){
    	  flash_red();
    	  if(button_check())
    		  i = 0;
      }
      next_state = RED;
      break;

    case FLASH_RED_END:
        // code for FLASH_RED_END state & logic for next_state
        for(int i = 0; i < 6; ++i){
    	    flash_red();
		    if(button_check()){
			    next_state = FLASH_RED_START;
			    break;
		    }
        }
        if(next_state == FLASH_RED_START)
        	break;
        else {
        	next_state = GREEN;
        	break;
        }

  }
  state = next_state; // update next state
}

int main()
{

	*buttonsTri = 0xF;
	*rgbLEDsTri = 0x0;

  // initialize crossing to a state from the enum
  state = GREEN;


  // keep on loopin'
  while(1)
  {
    // cycle through traffic light pattern
    FSM_tick();
  }

  return 0;
}
