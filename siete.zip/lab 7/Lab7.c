
 #include "xil_printf.h"
 #include "xparameters.h"
 #include "xgpio.h"
 #include "xintc.h"
 #include "FreeRTOS.h"
 #include "task.h"
 #include "semphr.h"
    
 // lights state
 typedef enum
 {
     GREEN,
     RED,
     RED_BLINK_START,
     RED_BLINK_END
 } State;



#define CHANNEL_1 1
#define CHANNEL_2 2
//light colors

#define RGB_GREEN 02222
#define RGB_RED 04444
#define RGB_OFF 00000
    
 //semaphore 
 SemaphoreHandle_t state_mutex;


XGpio btnGpio;             
XGpio ledGpio;            



State state;	
u8 btnPressed = FALSE;		
unsigned ledState;

TaskHandle_t SupervisorTaskHandle = NULL;
TaskHandle_t GreenTaskHandle = NULL;
TaskHandle_t RedBlinkStartTaskHandle = NULL;
TaskHandle_t RedTaskHandle = NULL;
TaskHandle_t RedBlinkEndTaskHandle = NULL;

void SupervisorTask(void *arg);
void GreenTask(void *arg);
void RedBlinkStartTask(void *arg);
void RedTask(void *arg);
void RedBlinkEndTask(void *arg);


void platform_init()
{
	
	XGpio_Initialize(&btnGpio, XPAR_GPIO_0_DEVICE_ID);
	XGpio_SetDataDirection(&btnGpio, CHANNEL_2, 0xF);


	
	XGpio_Initialize(&ledGpio, XPAR_GPIO_1_DEVICE_ID);
	XGpio_SetDataDirection(&ledGpio, CHANNEL_1, 0x0);
}


void createTasks(TaskHandle_t taskName, char taskNick)
{
	xTaskCreate(taskName, taskNick, configMINIMAL_STACK_SIZE,
		    NULL, tskIDLE_PRIORITY, &taskName);
}


void SupervisorTask(void *data)
{
	while(1)
	{


		switch (state)
		{
			case GREEN:
				vTaskResume(GreenTaskHandle);
				break;
			case RED_BLINK_START:
				vTaskResume(RedBlinkStartTaskHandle);
				break;
			case RED:
				vTaskResume(RedTaskHandle);
				break;
			case RED_BLINK_END:
				vTaskResume(RedBlinkEndTaskHandle);
				break;
		}
	}
}

//Red Blink 
void RedBlinkStartTask(void *data)
{

	unsigned int time = 0; <- time variable

	ledState = RGB_RED;

	vTaskSuspend(NULL);


	xil_printf("Red blink start task...\r\n");

	while(1)
	{
		
		XGpio_DiscreteWrite(&ledGpio, 1, ledState);

		time++; <- time increment

		if (time >= 12)
		{
			if (xSemaphoreTake(state_mutex, 10))
			{
				state = RED;
				time = 0;
				xSemaphoreGive(state_mutex);
			}
		}

		vTaskDelay(pdMS_TO_TICKS(500)); 

		ledState ^= RGB_RED; <- toggle on and off

		
		vTaskSuspend(NULL);
	}
}

//Red blink end task
void RedBlinkEndTask(void *data)
{
	
	unsigned int time = 0;

	
	ledState = RGB_OFF;

	vTaskSuspend(NULL);

	
	xil_printf("Red blink stop task...\r\n");

	while(1)
	{
		XGpio_DiscreteWrite(&ledGpio, 1, ledState);

		time++;

		if (time >= 12) 
		{
			if (xSemaphoreTake(state_mutex, 10))
			{
				state = GREEN;
				time = 0;
				xSemaphoreGive(state_mutex);
			}
		}

		vTaskDelay(pdMS_TO_TICKS(500));

		ledColor ^= RGB_RED; 

		vTaskSuspend(NULL);
	}
}


//green 
void GreenTask(void *data)
{

	ledState = RGB_GREEN;

	vTaskSuspend(NULL);

	xil_printf("Green task...\r\n");

	while(1)
	{
	
		XGpio_DiscreteWrite(&ledGpio, 1, ledState);



		if (XGpio_DiscreteRead(&btnGpio, 2) & 0xF)  
		{
			btnPressed = TRUE;
			xil_printf("Button Pressed...\n");
		}

		if (btnPressed)
		{
				if (xSemaphoreTake(state_mutex, 10))
				{
					state = RED_BLINK_START;
					//time = 0;
					btnPressed = FALSE;
					xSemaphoreGive(state_mutex);
				}
		}


		vTaskDelay(pdMS_TO_TICKS(250));  

		
		vTaskSuspend(NULL); <- Suspends to not jump
	}
}


    
//Red Task
void RedTask(void *data)
{
	
	unsigned int time = 0;
	ledState = RGB_RED;
	vTaskSuspend(NULL);


	xil_printf("Red task...\r\n");

	while(1)
	{
		XGpio_DiscreteWrite(&ledGpio, 1, ledState);

		time++;

		if (time >= 8) 
		{
			if (xSemaphoreTake(state_mutex, 10)) 
			{
				state = RED_BLINK_END;
				time = 0;
				xSemaphoreGive(state_mutex);
			}
		}

		vTaskDelay(pdMS_TO_TICKS(500));

		
		vTaskSuspend(NULL);
	}

}



 int main(void)
 {
     platform_init();
     //Create tasks
     createTask(RedBlinkStartTask, 'RedBlinkStartTask');
     createTask(RedTask, 'RedTask');
     createTask(RedBlinkEndTask, 'RedBlinkEndTask');
     createTask(SupervisorTask, 'SupervisorTask');
     createTask(GreenTask, 'GreenTask');
    
     state_mutex = xSemaphoreCreateMutex();

     state = Green;

     vTaskStartScheduler();

     return 0;
 }
